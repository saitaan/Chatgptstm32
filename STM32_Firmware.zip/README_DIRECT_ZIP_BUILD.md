# STM32 V16.5.9 — GitHub Direct ZIP Build

Repository layout:
- STM32_Firmware.zip
- .github/workflows/auto_zip_compile.yml

When STM32_Firmware.zip is committed, GitHub Actions:
1. extracts the firmware,
2. runs the bundled test runner when present,
3. adds the official STM32duino Board Manager index,
4. installs the STM32 Arduino core,
5. compiles for STM32F103C8T6 Blue Pill,
6. publishes the .bin/.hex/.elf as an artifact.

For future firmware revisions, replace STM32_Firmware.zip.
