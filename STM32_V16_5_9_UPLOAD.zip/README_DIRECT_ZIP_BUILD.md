# STM32 V16.5.9 — Direct ZIP Upload Build

1. Upload/replace `STM32_Firmware.zip` in GitHub.
2. GitHub Actions automatically extracts it.
3. The workflow compiles the STM32F103C8T6 firmware.
4. Download the generated `STM32-V16.5.9-firmware` artifact.

For a new firmware revision, replace only `STM32_Firmware.zip`.
