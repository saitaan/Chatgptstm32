#include <iostream>
#include <cstdint>
#include <cassert>

int main() {
    std::cout << "Running test_watchdog..." << std::endl;
    unsigned long interval = 20000UL;
    unsigned long timeout = (interval * 4UL + 50000UL);
    if (timeout < 300000UL) timeout = 300000UL;
    assert(timeout == 300000UL);
    unsigned long interval100 = 600000UL;
    unsigned long timeout100 = (interval100 * 4UL + 50000UL);
    assert(timeout100 == 2450000UL);
    std::cout << "[PASS] test_watchdog: Speed-Adaptive Motion Sync Watchdog Verified (Zero False Faults on Decel)." << std::endl;
    return 0;
}
