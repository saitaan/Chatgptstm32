#include <iostream>
#include <cassert>
#include <cstdint>
#include <random>
#include "../include/burst_queue.h"
#include "../include/motion_scheduler.h"

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Randomized Stress Testing (5 Seeds x 100,000 Scenarios = 500,000 Total)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    uint32_t seeds[] = {42, 12345, 99999, 54321, 777777};
    const uint32_t SCENARIOS_PER_SEED = 100000;

    for (int s_idx = 0; s_idx < 5; s_idx++) {
        uint32_t seed = seeds[s_idx];
        std::mt19937 rng(seed);
        std::uniform_int_distribution<uint32_t> burstDist(1, 256);
        std::uniform_int_distribution<uint32_t> dirDist(0, 1);
        std::uniform_int_distribution<uint32_t> actionDist(0, 9); // 0..6 enqueue, 7..9 dequeue

        BurstQueue queue;
        uint32_t totalEnqueued = 0;
        uint32_t totalDequeued = 0;

        for (uint32_t i = 0; i < SCENARIOS_PER_SEED; i++) {
            uint32_t action = actionDist(rng);

            if (action < 7 || queue.isEmpty()) {
                // Try enqueue if queue has capacity
                if (!queue.isFull()) {
                    uint32_t steps = burstDist(rng);
                    uint8_t  dir   = (uint8_t)dirDist(rng);
                    bool ok = queue.enqueue(steps, dir, i * 10, i);
                    assert(ok);
                    totalEnqueued++;
                } else {
                    // Queue full: consumer must dequeue
                    BurstItem item{};
                    bool ok = queue.dequeue(item);
                    assert(ok);
                    totalDequeued++;
                }
            } else {
                // Dequeue
                BurstItem item{};
                bool ok = queue.dequeue(item);
                assert(ok);
                totalDequeued++;
            }

            // Invariant check: dropped MUST be 0 under documented capacity
            assert(queue.droppedPulses == 0);
            assert(queue.overflowCount == 0);
            assert(queue.verifyInvariant());
        }

        // Drain remaining items
        BurstItem rem{};
        while (queue.dequeue(rem)) {
            totalDequeued++;
            assert(queue.verifyInvariant());
        }

        assert(queue.isEmpty());
        assert(queue.droppedPulses == 0);
        assert(queue.submittedPulses == queue.consumedPulses);

        std::cout << "[PASS] Seed " << seed << " (100,000 Scenarios) -> Pulses Conserved: "
                  << queue.consumedPulses << " | Invariant: EXACT MATCH (dropped=0)" << std::endl;
    }

    std::cout << "==========================================================" << std::endl;
    std::cout << "ALL 500,000 RANDOMIZED SCENARIOS PASSED (100% GREEN)" << std::endl;
    std::cout << "==========================================================" << std::endl;
    return 0;
}
