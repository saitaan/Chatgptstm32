#include <iostream>
#include <cstdint>
#include <cassert>
#include <vector>
#include <random>
#include <cstring>
#include "../include/pulsestep_persistence.h"

// =========================================================================
// AUTOMATED TEST SUITE: PRODUCTION-SAFE PULSESTEP PERSISTENCE (PROMPT 4Writing)
// Verifies:
// 1. Immediate RAM updates & dynamic dirty tracking (change back -> dirty=false).
// 2. Strict Flash wear protection (identical value -> 0 writes).
// 3. Motion-safety gating (no writes during acceleration, cruise, decel, burst, queue).
// 4. Deferred 60s auto-save at standstill.
// 5. Manual save safety (rejected during motion, skipped when unchanged).
// 6. Dual-slot transactional persistence with CRC32 & power-loss safety.
// 7. 10,000 randomized stress cycles.
// =========================================================================

// Simulated EEPROM Emulation Storage (1024 bytes Flash page)
struct MockEEPROMStorage {
    uint8_t memory[1024];

    MockEEPROMStorage() {
        memset(memory, 0xFF, sizeof(memory)); // Erased Flash state
    }

    void read(int offset, void *dest, size_t size) const {
        assert(offset + size <= sizeof(memory));
        memcpy(dest, &memory[offset], size);
    }

    void write(int offset, const void *src, size_t size) {
        assert(offset + size <= sizeof(memory));
        memcpy(&memory[offset], src, size);
    }

    void corrupt(int offset, uint8_t byteMask) {
        memory[offset] ^= byteMask;
    }
};

// Simulated Persistence Driver with Dual-Slot Transactional Architecture
class SimulatedPersistenceDriver {
public:
    MockEEPROMStorage storage;
    PulseStepPersistenceManager mgr;
    uint32_t flashWriteCount;

    SimulatedPersistenceDriver() : flashWriteCount(0) {}

    // Boot / Load sequence: inspects both slots, selects newest valid record
    bool bootLoad() {
        MachineConfigRecord rec0, rec1;
        storage.read(0, &rec0, sizeof(MachineConfigRecord));
        storage.read(128, &rec1, sizeof(MachineConfigRecord));

        bool v0 = PulseStepPersistenceManager::validateRecord(rec0);
        bool v1 = PulseStepPersistenceManager::validateRecord(rec1);

        if (v0 && v1) {
            if (rec0.seq >= rec1.seq) {
                mgr.applyPayload(rec0.payload, rec0.seq, 0);
            } else {
                mgr.applyPayload(rec1.payload, rec1.seq, 1);
            }
            return true;
        } else if (v0) {
            mgr.applyPayload(rec0.payload, rec0.seq, 0);
            return true;
        } else if (v1) {
            mgr.applyPayload(rec1.payload, rec1.seq, 1);
            return true;
        } else {
            // Uninitialized or corrupted Flash: load defaults into RAM without writing Flash!
            mgr.resetToFactoryDefaults();
            mgr.syncStoredWithRam();
            return false;
        }
    }

    // Safe Persistence Execution (Gated by idle check & dirty check)
    // Returns: 1 = Written & Verified, 0 = Skipped (unchanged), -1 = Rejected (motion active)
    int executeSave(uint32_t currentRPM, int stepsRemaining, bool hwBurstActive,
                    bool queueEmpty, int movementState, bool isSensorFault, bool isSyncLost) {
        // 1. Idle Precondition Check
        if (!mgr.isMachineSafelyIdle(currentRPM, stepsRemaining, hwBurstActive,
                                    queueEmpty, movementState, isSensorFault, isSyncLost)) {
            return -1; // Motion active: saving strictly prohibited!
        }

        // 2. Strict Write Suppression: If unchanged, SKIP WRITE completely!
        if (!mgr.isAnyDirty()) {
            return 0; // 0 writes needed
        }

        // 3. Dual-slot alternate write
        uint32_t targetSlot = 1 - mgr.activeSlot;
        int targetOffset = (targetSlot == 0) ? 0 : 128;
        uint32_t nextSeq = mgr.lastSeq + 1;

        MachineConfigRecord newRec = mgr.buildCurrentRecord(nextSeq);

        // Atomic write to alternate slot
        storage.write(targetOffset, &newRec, sizeof(MachineConfigRecord));
        flashWriteCount++;
        mgr.flashWriteCount++;

        // 4. Verification Read-back
        MachineConfigRecord readBack;
        storage.read(targetOffset, &readBack, sizeof(MachineConfigRecord));
        if (PulseStepPersistenceManager::validateRecord(readBack) &&
            memcmp(&newRec, &readBack, sizeof(MachineConfigRecord)) == 0) {
            mgr.activeSlot = targetSlot;
            mgr.lastSeq = nextSeq;
            mgr.syncStoredWithRam(); // Clears dirty flag!
            return 1; // Successfully persisted & verified
        } else {
            // Write verification failed: alternate slot corrupt, active slot untouched!
            return -2;
        }
    }
};

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Production-Safe PulseStep Persistence Engine" << std::endl;
    std::cout << "==========================================================" << std::endl;

    // ---------------------------------------------------------------------
    // 1. Basic Tests: Default Load & Range Validation
    // ---------------------------------------------------------------------
    {
        SimulatedPersistenceDriver driver;
        bool loaded = driver.bootLoad();
        assert(!loaded); // Fresh erased memory
        assert(driver.mgr.ram_p5 == 113176848ULL);
        assert(driver.mgr.stored_p5 == 113176848ULL);
        assert(!driver.mgr.isAnyDirty());
        assert(driver.flashWriteCount == 0); // Boot does NOT cause flash write

        // Range boundary checks
        MachineConfigPayload p = driver.mgr.buildCurrentRecord(1).payload;
        assert(PulseStepPersistenceManager::validatePayload(p));

        p.p5_fixed = PULSE_STEP_MIN_FIXED - 1; // Below min
        assert(!PulseStepPersistenceManager::validatePayload(p));

        p.p5_fixed = PULSE_STEP_MAX_FIXED + 1; // Above max
        assert(!PulseStepPersistenceManager::validatePayload(p));
        std::cout << "[PASS] 1. Basic Tests: Default Load & Range Validation Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // 2. Dirty-State & Reversion Tracking Tests
    // ---------------------------------------------------------------------
    {
        SimulatedPersistenceDriver driver;
        driver.bootLoad();

        uint64_t initialP5 = driver.mgr.ram_p5;
        assert(!driver.mgr.isPulseStepDirty(1));

        // User increments UP by 1 step
        driver.mgr.ram_p5 += 1000000ULL;
        assert(driver.mgr.isPulseStepDirty(1));
        assert(driver.mgr.isAnyDirty());

        // User decrements DOWN back to original stored value
        driver.mgr.ram_p5 = initialP5;
        assert(!driver.mgr.isPulseStepDirty(1));
        assert(!driver.mgr.isAnyDirty()); // Reverting to stored value CLEARS dirty!

        // Attempt save when reverted
        int res = driver.executeSave(0, 0, false, true, 0, false, false);
        assert(res == 0); // Write suppressed!
        assert(driver.flashWriteCount == 0);
        std::cout << "[PASS] 2. Dirty-State & Reversion Tracking (A -> B -> A => 0 writes) Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // 3. Flash Wear Protection & 1000 Idle Checks
    // ---------------------------------------------------------------------
    {
        SimulatedPersistenceDriver driver;
        driver.bootLoad();

        // 1000 Idle loops without modification -> 0 writes
        for (int i = 0; i < 1000; i++) {
            int res = driver.executeSave(0, 0, false, true, 0, false, false);
            assert(res == 0);
        }
        assert(driver.flashWriteCount == 0);

        // 100 button presses (10 -> 11 -> 12 -> ... -> 110)
        for (int i = 0; i < 100; i++) {
            driver.mgr.ram_p5 += 1000000ULL;
            assert(driver.mgr.isPulseStepDirty(1));
            // During adjustment, no Flash write occurs
            assert(driver.flashWriteCount == 0);
        }

        // Machine becomes idle -> exactly ONE write occurs
        int res = driver.executeSave(0, 0, false, true, 0, false, false);
        assert(res == 1);
        assert(driver.flashWriteCount == 1);
        assert(!driver.mgr.isAnyDirty());

        // Subsequent 1000 idle checks -> 0 additional writes
        for (int i = 0; i < 1000; i++) {
            int res2 = driver.executeSave(0, 0, false, true, 0, false, false);
            assert(res2 == 0);
        }
        assert(driver.flashWriteCount == 1);
        std::cout << "[PASS] 3. Flash Wear Protection (100 presses -> 1 write, 1000 idle -> 0 writes) Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // 4. Motion-Safety Gating (No writes during any motion state)
    // ---------------------------------------------------------------------
    {
        SimulatedPersistenceDriver driver;
        driver.bootLoad();
        driver.mgr.ram_p5 += 2000000ULL; // Dirty in RAM

        // A. Machine running (RPM > 0)
        assert(driver.executeSave(1500, 0, false, true, 1 /* RUNNING */, false, false) == -1);
        assert(driver.flashWriteCount == 0);

        // B. Active steps remaining in DDA
        assert(driver.executeSave(0, 45, false, true, 1, false, false) == -1);
        assert(driver.flashWriteCount == 0);

        // C. Hardware burst active in TIM2
        assert(driver.executeSave(0, 0, true, true, 1, false, false) == -1);
        assert(driver.flashWriteCount == 0);

        // D. Queue non-empty
        assert(driver.executeSave(0, 0, false, false, 0, false, false) == -1);
        assert(driver.flashWriteCount == 0);

        // E. Movement state STOPPING
        assert(driver.executeSave(0, 0, false, true, 2 /* STOPPING */, false, false) == -1);
        assert(driver.flashWriteCount == 0);

        // F. Sensor Fault active
        assert(driver.executeSave(0, 0, false, true, 0, true /* FAULT */, false) == -1);
        assert(driver.flashWriteCount == 0);

        // G. Machine safely stopped: RPM=0, steps=0, !burst, queueEmpty, IDLE, no fault
        assert(driver.executeSave(0, 0, false, true, 0, false, false) == 1);
        assert(driver.flashWriteCount == 1);
        std::cout << "[PASS] 4. Motion-Safety Gating (All motion states blocked) Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // 5. User Sequence Test: 10 -> 11 -> 12 -> 13 -> 12 -> 14
    // ---------------------------------------------------------------------
    {
        SimulatedPersistenceDriver driver;
        driver.bootLoad();
        uint64_t baseP = 10000000ULL; // 10.00
        driver.mgr.ram_p5 = baseP;
        driver.executeSave(0, 0, false, true, 0, false, false);
        uint32_t baselineWrites = driver.flashWriteCount;

        // Sequence: 10 -> 11 -> 12 -> 13 -> 12 -> 14
        driver.mgr.ram_p5 = 11000000ULL; assert(driver.flashWriteCount == baselineWrites);
        driver.mgr.ram_p5 = 12000000ULL; assert(driver.flashWriteCount == baselineWrites);
        driver.mgr.ram_p5 = 13000000ULL; assert(driver.flashWriteCount == baselineWrites);
        driver.mgr.ram_p5 = 12000000ULL; assert(driver.flashWriteCount == baselineWrites);
        driver.mgr.ram_p5 = 14000000ULL; assert(driver.flashWriteCount == baselineWrites);

        // Machine settles at idle
        int res = driver.executeSave(0, 0, false, true, 0, false, false);
        assert(res == 1);
        assert(driver.flashWriteCount == baselineWrites + 1);
        assert(driver.mgr.stored_p5 == 14000000ULL);
        std::cout << "[PASS] 5. User Sequence (10 -> 11 -> 12 -> 13 -> 12 -> 14 => exactly 1 save of 14) Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // 6. User Sequence Test: 10 -> 11 -> 12 -> 11 -> 10 (Zero writes)
    // ---------------------------------------------------------------------
    {
        SimulatedPersistenceDriver driver;
        driver.bootLoad();
        uint64_t baseP = 10000000ULL;
        driver.mgr.ram_p5 = baseP;
        driver.executeSave(0, 0, false, true, 0, false, false);
        uint32_t baselineWrites = driver.flashWriteCount;

        // Sequence: 10 -> 11 -> 12 -> 11 -> 10
        driver.mgr.ram_p5 = 11000000ULL;
        driver.mgr.ram_p5 = 12000000ULL;
        driver.mgr.ram_p5 = 11000000ULL;
        driver.mgr.ram_p5 = 10000000ULL;

        assert(!driver.mgr.isPulseStepDirty(1));
        int res = driver.executeSave(0, 0, false, true, 0, false, false);
        assert(res == 0); // No write!
        assert(driver.flashWriteCount == baselineWrites);
        std::cout << "[PASS] 6. User Sequence (10 -> 11 -> 12 -> 11 -> 10 => 0 writes) Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // 7. Dual-Slot Transactional Ping-Pong & Power-Loss Recovery
    // ---------------------------------------------------------------------
    {
        SimulatedPersistenceDriver driver;
        driver.bootLoad();

        // Transaction 1: saves to Slot 1 (since activeSlot=0)
        driver.mgr.ram_p5 = 120000000ULL;
        driver.executeSave(0, 0, false, true, 0, false, false);
        assert(driver.mgr.activeSlot == 1);
        assert(driver.mgr.lastSeq == 1);

        // Transaction 2: saves to Slot 0
        driver.mgr.ram_p5 = 130000000ULL;
        driver.executeSave(0, 0, false, true, 0, false, false);
        assert(driver.mgr.activeSlot == 0);
        assert(driver.mgr.lastSeq == 2);

        // Simulate reboot: reads newest valid record (Slot 0, seq 2)
        SimulatedPersistenceDriver rebootDriver;
        rebootDriver.storage = driver.storage;
        assert(rebootDriver.bootLoad() == true);
        assert(rebootDriver.mgr.ram_p5 == 130000000ULL);
        assert(rebootDriver.mgr.lastSeq == 2);
        assert(rebootDriver.mgr.activeSlot == 0);

        // Simulate power loss during write to Slot 1: corrupt Slot 1 memory
        rebootDriver.storage.corrupt(128 + 10, 0xAA); // Corrupt payload in Slot 1
        SimulatedPersistenceDriver recoveredDriver;
        recoveredDriver.storage = rebootDriver.storage;
        assert(recoveredDriver.bootLoad() == true);
        // Correctly recovered from uncorrupted Slot 0!
        assert(recoveredDriver.mgr.ram_p5 == 130000000ULL);
        assert(recoveredDriver.mgr.activeSlot == 0);
        std::cout << "[PASS] 7. Dual-Slot Transactional Ping-Pong & Power-Loss Recovery Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // 8. 10,000 Randomized Stress Cycles
    // ---------------------------------------------------------------------
    {
        std::mt19937 rng(4242);
        std::uniform_int_distribution<int> deltaDist(-5, 5);
        std::uniform_int_distribution<int> rpmDist(0, 4000);
        std::uniform_int_distribution<int> actionDist(0, 5);

        SimulatedPersistenceDriver driver;
        driver.bootLoad();

        uint64_t groundTruthStored = driver.mgr.stored_p5;
        uint64_t groundTruthRam    = driver.mgr.ram_p5;

        for (int cycle = 0; cycle < 10000; cycle++) {
            int action = actionDist(rng);

            if (action == 0 || action == 1) {
                // User adjusts PulseStep
                int delta = deltaDist(rng);
                int64_t newP = (int64_t)groundTruthRam + (int64_t)delta * 1000000LL;
                if (newP >= (int64_t)PULSE_STEP_MIN_FIXED && newP <= (int64_t)PULSE_STEP_MAX_FIXED) {
                    groundTruthRam = (uint64_t)newP;
                    driver.mgr.ram_p5 = groundTruthRam;
                }
            } else if (action == 2) {
                // User reverts to stored
                groundTruthRam = groundTruthStored;
                driver.mgr.ram_p5 = groundTruthRam;
            }

            // Verify dirty tracking invariant
            bool expectedDirty = (groundTruthRam != groundTruthStored);
            assert(driver.mgr.isPulseStepDirty(1) == expectedDirty);

            // Simulate machine state
            uint32_t rpm = rpmDist(rng);
            bool isMoving = (rpm > 0);
            int steps = isMoving ? 20 : 0;
            bool burst = isMoving;
            bool qEmpty = !isMoving;
            int state = isMoving ? 1 : 0;

            uint32_t writesBefore = driver.flashWriteCount;
            int res = driver.executeSave(rpm, steps, burst, qEmpty, state, false, false);

            if (isMoving) {
                assert(res == -1); // Motion blocked
                assert(driver.flashWriteCount == writesBefore);
            } else {
                if (expectedDirty) {
                    assert(res == 1);
                    assert(driver.flashWriteCount == writesBefore + 1);
                    groundTruthStored = groundTruthRam; // Saved!
                    assert(!driver.mgr.isPulseStepDirty(1));
                } else {
                    assert(res == 0); // Skipped!
                    assert(driver.flashWriteCount == writesBefore);
                }
            }
        }
        std::cout << "[PASS] 8. 10,000 Randomized Stress Cycles (0 lost values, 0 redundant writes) Verified." << std::endl;
    }

    std::cout << "==========================================================" << std::endl;
        // ---------------------------------------------------------------------
    // 9. Formal Auto-Save Continuous 60-Second Qualification State Machine Audit (Prompt 6Writing Section 1)
    // ---------------------------------------------------------------------
    {
        AutoSaveQualificationEngine engine(60000UL);

        // Sub-test A: 59.9 sec qualified -> NO save allowed
        engine.reset();
        engine.update(350, 300, true, false, false, false, true, 1000);
        assert(engine.state == SAVE_QUALIFYING);
        assert(!engine.autoSavePendingStandstill);
        engine.update(350, 300, true, false, false, false, true, 1000 + 59900); // 59.9s
        assert(engine.state == SAVE_QUALIFYING);
        assert(!engine.autoSavePendingStandstill);

        // Sub-test B: exactly 60.0 sec qualified -> save allowed
        engine.update(350, 300, true, false, false, false, true, 1000 + 60000); // 60.0s
        assert(engine.state == SAVE_QUALIFIED);
        assert(engine.autoSavePendingStandstill);

        // Sub-test C: 60 sec + 1 ms -> save allowed
        engine.reset();
        engine.update(400, 300, true, false, false, false, true, 2000);
        engine.update(400, 300, true, false, false, false, true, 2000 + 60001); // 60s + 1ms
        assert(engine.state == SAVE_QUALIFIED);
        assert(engine.autoSavePendingStandstill);

        // Sub-test D: 30 sec qualified -> RPM drops below threshold (250 RPM) -> timer resets!
        engine.reset();
        engine.update(350, 300, true, false, false, false, true, 5000);
        engine.update(350, 300, true, false, false, false, true, 5000 + 30000); // 30s
        assert(engine.state == SAVE_QUALIFYING);
        // Dip to 250 RPM (< 300)
        engine.update(250, 300, true, false, false, false, true, 5000 + 31000);
        assert(engine.state == SAVE_NOT_QUALIFIED);
        assert(!engine.autoSavePendingStandstill);
        assert(engine.qualificationStartMs == 0);

        // Sub-test E: 59 sec qualified -> RPM below threshold -> timer resets!
        engine.reset();
        engine.update(350, 300, true, false, false, false, true, 10000);
        engine.update(350, 300, true, false, false, false, true, 10000 + 59000); // 59s
        assert(engine.state == SAVE_QUALIFYING);
        // Dip to 290 RPM (< 300)
        engine.update(290, 300, true, false, false, false, true, 10000 + 59500);
        assert(engine.state == SAVE_NOT_QUALIFIED);
        assert(!engine.autoSavePendingStandstill);

        // Sub-test F: RPM oscillation around threshold -> no false qualification
        engine.reset();
        uint32_t t = 100000;
        for (int i = 0; i < 100; i++) {
            uint32_t oscRPM = (i % 2 == 0) ? 310 : 290;
            engine.update(oscRPM, 300, true, false, false, false, true, t);
            assert(!engine.autoSavePendingStandstill);
            t += 500;
        }
        assert(engine.state == SAVE_NOT_QUALIFIED);

        // Sub-test G: RPM sensor timeout / invalid -> qualification reset
        engine.reset();
        engine.update(350, 300, true, false, false, false, true, 200000);
        engine.update(350, 300, true, false, false, false, true, 200000 + 40000); // 40s
        assert(engine.state == SAVE_QUALIFYING);
        // Sensor times out / becomes stale
        engine.update(350, 300, false /* invalid */, false, false, false, true, 200000 + 41000);
        assert(engine.state == SAVE_NOT_QUALIFIED);
        assert(!engine.autoSavePendingStandstill);

        // Sub-test H: Safety fault during qualification -> reset
        engine.reset();
        engine.update(350, 300, true, false, false, false, true, 300000);
        engine.update(350, 300, true, false, false, false, true, 300000 + 45000); // 45s
        assert(engine.state == SAVE_QUALIFYING);
        // Safety fault trips (PA3 / PB0)
        engine.update(350, 300, true, true /* fault */, false, false, true, 300000 + 46000);
        assert(engine.state == SAVE_NOT_QUALIFIED);
        assert(!engine.autoSavePendingStandstill);

        // Sub-test I: Machine stop/idle during qualification -> reset
        engine.reset();
        engine.update(350, 300, true, false, false, false, true, 400000);
        engine.update(350, 300, true, false, false, false, true, 400000 + 50000); // 50s
        assert(engine.state == SAVE_QUALIFYING);
        // Machine stops (0 RPM, idle)
        engine.update(0, 300, true, false, false, true /* idle */, true, 400000 + 51000);
        assert(engine.state == SAVE_NOT_QUALIFIED);
        assert(!engine.autoSavePendingStandstill);

        // Sub-test J: Restart after reset requires a fresh full 60-sec qualification
        engine.update(350, 300, true, false, false, false, true, 400000 + 60000);
        assert(engine.state == SAVE_QUALIFYING);
        assert(engine.qualificationStartMs == 400000 + 60000);
        // 59.9s later
        engine.update(350, 300, true, false, false, false, true, 400000 + 60000 + 59900);
        assert(engine.state == SAVE_QUALIFYING);
        assert(!engine.autoSavePendingStandstill);
        // Full 60s
        engine.update(350, 300, true, false, false, false, true, 400000 + 60000 + 60000);
        assert(engine.state == SAVE_QUALIFIED);
        assert(engine.autoSavePendingStandstill);

        std::cout << "[PASS] 9. Formal Auto-Save Continuous 60-Second Qualification State Machine Audit (10/10 sub-tests) Verified." << std::endl;
    }

    std::cout << "SUCCESS: ALL PULSESTEP PERSISTENCE TESTS PASSED (100% GREEN)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    return 0;
}
