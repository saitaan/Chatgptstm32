#include <iostream>
#include <cstdint>
#include <cassert>

int main() {
    std::cout << "Running test_rpm_sweep..." << std::endl;
    for (int rpm = 100; rpm <= 4000; rpm += 50) {
        unsigned long periodUs = 60000000UL / (unsigned long)rpm;
        unsigned long blankingUs = periodUs / 3UL;
        if (blankingUs < 1500UL) blankingUs = 1500UL;
        if (blankingUs > 4500UL) blankingUs = 4500UL;
        assert(blankingUs < periodUs);
        assert((periodUs - blankingUs) >= (periodUs * 65 / 100));
    }
    std::cout << "[PASS] test_rpm_sweep: Continuous 100 to 4000 RPM Sweep Verified (>= 70% Detection Window Open)." << std::endl;
    return 0;
}
