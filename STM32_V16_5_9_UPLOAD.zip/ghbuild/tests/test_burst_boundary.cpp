#include <iostream>
#include <vector>
#include <cstdint>
#include <cassert>
#include "motion_scheduler.h"
#include "burst_queue.h"

// Comprehensive test for mid-burst and burst boundary triggers (Cases A through G)
int main() {
    std::cout << "Running test_burst_boundary..." << std::endl;

    BurstQueue q;

    // Case A: Isolated burst through queue
    {
        q.reset();
        assert(q.enqueue(113, 0, 1000, 1));
        BurstItem item{};
        assert(q.dequeue(item));
        assert(item.stepCount == 113);
        assert(q.isEmpty());
        assert(q.verifyInvariant());
    }

    // Case B: Trigger arriving at early acceleration (step 2 of 113)
    {
        q.reset();
        assert(q.enqueue(113, 0, 1000, 1));
        BurstItem active{};
        assert(q.dequeue(active));
        // Mid-burst trigger arrives:
        assert(q.enqueue(50, 0, 1140, 2));
        assert(q.queuedSteps() == 50);

        // Chained burst dequeues
        BurstItem chained{};
        assert(q.dequeue(chained));
        assert(chained.stepCount == 50);
        assert(q.verifyInvariant());
    }

    // Case C: Trigger arriving at plateau (step 50 of 113)
    {
        q.reset();
        assert(q.enqueue(113, 0, 1000, 1));
        BurstItem active{};
        assert(q.dequeue(active));
        // Mid-burst trigger arrives at plateau:
        assert(q.enqueue(75, 0, 4500, 2));
        assert(q.queuedSteps() == 75);

        BurstItem chained{};
        assert(q.dequeue(chained));
        assert(chained.stepCount == 75);
        assert(q.verifyInvariant());
    }

    // Case D: Trigger arriving at late deceleration (step 110 of 113, remaining = 3)
    {
        q.reset();
        assert(q.enqueue(113, 0, 1000, 1));
        BurstItem active{};
        assert(q.dequeue(active));
        // Mid-burst trigger arrives during decel:
        assert(q.enqueue(113, 0, 8000, 2));
        assert(q.count() == 1);
        BurstItem nextItem{};
        assert(q.dequeue(nextItem));
        assert(nextItem.stepCount == 113);
        assert(q.verifyInvariant());
    }

    // Case E: Trigger arriving exactly at final step boundary (remaining = 1)
    {
        q.reset();
        assert(q.enqueue(113, 0, 1000, 1));
        BurstItem active{};
        assert(q.dequeue(active));
        // Final pulse boundary trigger
        assert(q.enqueue(113, 0, 8500, 2));
        BurstItem nextItem{};
        assert(q.dequeue(nextItem));
        assert(nextItem.stepCount == 113);
        assert(q.verifyInvariant());
    }

    // Case F: Rapid consecutive triggers (burst burst burst)
    {
        q.reset();
        assert(q.enqueue(20, 0, 1000, 1));
        BurstItem active{};
        assert(q.dequeue(active));

        // 5 rapid triggers arrive while active is running
        for (uint32_t i = 2; i <= 6; i++) {
            assert(q.enqueue(20, 0, 1000 + i * 100, i));
        }
        assert(q.count() == 5);
        assert(q.queuedSteps() == 100);

        uint32_t totalConsumed = active.stepCount;
        while (!q.isEmpty()) {
            BurstItem it{};
            assert(q.dequeue(it));
            totalConsumed += it.stepCount;
        }
        assert(totalConsumed == 120);
        assert(q.verifyInvariant());
    }

    // Case G: Queue Full / Capacity Exceeded (Deterministic Reject Policy)
    {
        q.reset();
        for (uint32_t i = 1; i <= BURST_QUEUE_CAPACITY; i++) {
            assert(q.enqueue(10, 0, i * 100, i));
        }
        assert(q.isFull());
        // 17th enqueue MUST be safely rejected, incrementing overflowCount
        assert(!q.enqueue(10, 0, 9999, 99));
        assert(q.overflowCount == 1);
        assert(q.droppedPulses == 10);
        assert(q.verifyInvariant());
    }

    std::cout << "[PASS] test_burst_boundary: Boundary Race Conditions (Cases A, B, C, D, E, F, G) Verified Zero Pulse Loss." << std::endl;
    return 0;
}
