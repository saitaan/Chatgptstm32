#include <iostream>
#include <cassert>
#include <cstdint>
#include "../include/burst_queue.h"

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Formal Lock-Free SPSC Burst Queue Verification" << std::endl;
    std::cout << "==========================================================" << std::endl;

    BurstQueue q;

    // 1. Empty Queue Verification
    assert(q.isEmpty());
    assert(q.count() == 0);
    assert(q.queuedSteps() == 0);
    BurstItem dummy{};
    assert(!q.dequeue(dummy));
    assert(q.verifyInvariant());
    std::cout << "[PASS] 1. Empty Queue Invariants Verified." << std::endl;

    // 2. Single Item Enqueue and Dequeue
    assert(q.enqueue(113, 0, 1000, 1));
    assert(!q.isEmpty());
    assert(q.count() == 1);
    assert(q.queuedSteps() == 113);
    assert(q.verifyInvariant());

    BurstItem item{};
    assert(q.dequeue(item));
    assert(item.stepCount == 113);
    assert(item.direction == 0);
    assert(item.timestampUs == 1000);
    assert(item.seq == 1);
    assert(q.isEmpty());
    assert(q.count() == 0);
    assert(q.queuedSteps() == 0);
    assert(q.verifyInvariant());
    std::cout << "[PASS] 2. Single Item Enqueue/Dequeue Invariant Verified." << std::endl;

    // 3. Fill Queue to Exact Capacity (16 items)
    for (uint32_t i = 0; i < BURST_QUEUE_CAPACITY; i++) {
        assert(q.enqueue(100 + i, (i % 2), 2000 + i * 50, i + 1));
        assert(q.verifyInvariant());
    }
    assert(q.isFull());
    assert(q.count() == BURST_QUEUE_CAPACITY);
    std::cout << "[PASS] 3. Queue Exact Capacity (16 items) Verified." << std::endl;

    // 4. Explicit Overflow Detection (17th item MUST fail, never overwrite)
    uint32_t preOverflowConsumed = q.consumedPulses;
    uint32_t preOverflowQueued   = q.queuedSteps();
    assert(!q.enqueue(999, 1, 9999, 99)); // Must reject!
    assert(q.overflowCount == 1);
    assert(q.droppedPulses == 999);
    assert(q.consumedPulses == preOverflowConsumed);
    assert(q.queuedSteps() == preOverflowQueued);
    assert(q.verifyInvariant());
    std::cout << "[PASS] 4. Explicit Overflow Detection & Protection Verified." << std::endl;

    // 5. Drain Queue Completely and Verify Data Integrity
    for (uint32_t i = 0; i < BURST_QUEUE_CAPACITY; i++) {
        assert(q.dequeue(item));
        assert(item.stepCount == 100 + i);
        assert(item.direction == (i % 2));
        assert(item.timestampUs == 2000 + i * 50);
        assert(item.seq == i + 1);
        assert(q.verifyInvariant());
    }
    assert(q.isEmpty());
    std::cout << "[PASS] 5. Full Drain FIFO Ordering Verified." << std::endl;

    // 6. Continuous Wraparound Test (100,000 cycles)
    for (uint32_t cycle = 0; cycle < 100000; cycle++) {
        uint32_t burstSize = (cycle % 256) + 1;
        assert(q.enqueue(burstSize, (cycle & 1), cycle * 10, cycle));
        assert(q.dequeue(item));
        assert(item.stepCount == burstSize);
        assert(item.seq == cycle);
        if ((cycle % 10000) == 0) {
            assert(q.verifyInvariant());
        }
    }
    assert(q.verifyInvariant());
    assert(q.droppedPulses == 999); // Only the deliberate overflow above
    assert(q.isEmpty());
    std::cout << "[PASS] 6. 100,000 Continuous Wraparound Cycles Verified." << std::endl;

    // 7. Abort Operation Verification (Emergency Stop)
    q.reset();
    q.enqueue(50, 0, 100, 1);
    q.enqueue(75, 1, 200, 2);
    q.enqueue(100, 0, 300, 3);
    assert(q.queuedSteps() == 225);
    uint32_t aborted = q.abortAll();
    assert(aborted == 225);
    assert(q.isEmpty());
    assert(q.abortedPulses == 225);
    assert(q.verifyInvariant());
    std::cout << "[PASS] 7. E-Stop Queue Flush & Abort Accounting Verified." << std::endl;

    std::cout << "==========================================================" << std::endl;
    std::cout << "ALL FORMAL QUEUE TESTS PASSED (100% GREEN)" << std::endl;
    std::cout << "==========================================================" << std::endl;
    return 0;
}
