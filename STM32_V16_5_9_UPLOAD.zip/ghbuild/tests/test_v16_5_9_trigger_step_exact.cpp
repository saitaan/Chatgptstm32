#include <iostream>
#include <iomanip>
#include <cstdint>
#include <cassert>
#include <vector>
#include <cmath>
#include <string>
#include <fstream>
#include <sstream>
#include <thread>
#include <atomic>

#include "burst_queue.h"
#include "motion_scheduler.h"
#include "hardware_capture_spec.h"
#include "pulsestep_persistence.h"

// =========================================================================
// COMPREHENSIVE 26-SCENARIO VERIFICATION SUITE FOR STM32 ZIPPER CNC V16.5.9
// Verifies all 26 required verification scenarios under realistic, edge,
// and hardware-boundary stress conditions.
// =========================================================================

struct SimulatedMachineEngine {
    BurstQueue queue;
    DdaAccumulator dda;
    HardwareCaptureStreamEngine captureEngine;
    FlashSaveTransactionEngine flashTx;

    // Diagnostics counters
    uint32_t receivedTriggers;
    uint32_t acceptedTriggers;
    uint32_t generatedStepBursts;
    uint32_t completedStepBursts;
    uint32_t queueOverflowCount;
    uint32_t captureOverrunCount;
    uint32_t deferredTriggerCount;
    uint32_t rejectedTriggerCount;

    // Pulse tracking
    uint32_t totalRequestedPulses;
    uint32_t totalCompletedPulses;
    uint32_t totalAbortedPulses;

    // Timer & Motion state
    bool hwBurstActive;
    uint32_t hwBurstStepsTarget;
    uint32_t hwBurstStepsDone;
    uint16_t currentARR;
    uint16_t currentCCR2;
    uint32_t activePulseWidth;
    bool hasValidPriorTrigger;
    uint32_t lastTriggerMicros;
    uint32_t lastMeasuredIntervalUs;
    uint32_t currentRPM;
    uint32_t maxRPMSetting;
    uint8_t  motorDirection;
    int      movementState; // 0: IDLE, 1: RUNNING, 3: COMPLETE, 4: FAULT
    bool     isTriggerOverflowTripped;
    bool     isSensorFaultTripped;
    bool     motionRelayActive;

    SimulatedMachineEngine() {
        reset();
    }

    void reset() {
        queue.reset();
        dda.reset();
        memset(&captureEngine.diag, 0, sizeof(captureEngine.diag));
        flashTx.reset();

        receivedTriggers = 0;
        acceptedTriggers = 0;
        generatedStepBursts = 0;
        completedStepBursts = 0;
        queueOverflowCount = 0;
        captureOverrunCount = 0;
        deferredTriggerCount = 0;
        rejectedTriggerCount = 0;

        totalRequestedPulses = 0;
        totalCompletedPulses = 0;
        totalAbortedPulses = 0;

        hwBurstActive = false;
        hwBurstStepsTarget = 0;
        hwBurstStepsDone = 0;
        currentARR = 69;
        currentCCR2 = 65;
        activePulseWidth = 70;
        hasValidPriorTrigger = false;
        lastTriggerMicros = 0;
        lastMeasuredIntervalUs = 0;
        currentRPM = 0;
        maxRPMSetting = 3000;
        motorDirection = 0;
        movementState = 0; // IDLE
        isTriggerOverflowTripped = false;
        isSensorFaultTripped = false;
        motionRelayActive = false;
    }

    // Emulated startHardwareTimerBurst
    void startHardwareTimerBurst(uint32_t stepCount, uint32_t nowUs, uint16_t burstPeriodUs = 70) {
        if (stepCount == 0 || movementState == 4 /* FAULT */) return;

        static uint32_t s_seq = 0;
        s_seq++;

        if (hwBurstActive) {
            bool enqueued = queue.enqueue(stepCount, motorDirection, nowUs, s_seq, burstPeriodUs, (uint32_t)burstPeriodUs << 16);
            if (enqueued) {
                generatedStepBursts++;
                movementState = 1; // RUNNING
            } else {
                queueOverflowCount++;
                isTriggerOverflowTripped = true;
                movementState = 4; // FAULT
                motionRelayActive = true;
            }
            return;
        }

        bool enqueued = queue.enqueue(stepCount, motorDirection, nowUs, s_seq, burstPeriodUs, (uint32_t)burstPeriodUs << 16);
        if (!enqueued) {
            queueOverflowCount++;
            isTriggerOverflowTripped = true;
            movementState = 4; // FAULT
            motionRelayActive = true;
            return;
        }

        BurstItem item{};
        queue.dequeue(item);

        generatedStepBursts++;
        hwBurstStepsTarget = item.stepCount;
        hwBurstStepsDone = 0;
        hwBurstActive = true;
        movementState = 1; // RUNNING
        activePulseWidth = item.periodUs;

        currentARR = (item.periodUs > 1) ? (item.periodUs - 1) : 1;
        uint16_t pWidth = (currentARR > 5) ? 5 : (currentARR / 2);
        if (pWidth < 2) pWidth = 2;
        currentCCR2 = currentARR - pWidth + 1;
    }

    // Emulated stepTimerCallback (invoked once per step period)
    void stepTimerTick() {
        if (!hwBurstActive || movementState == 4) return;

        hwBurstStepsDone++;
        totalCompletedPulses++;

        if (hwBurstStepsDone >= hwBurstStepsTarget) {
            completedStepBursts++;
            BurstItem nextBurst{};
            if (queue.dequeue(nextBurst)) {
                // Seamlessly chain next burst
                hwBurstStepsTarget = nextBurst.stepCount;
                hwBurstStepsDone = 0;
                activePulseWidth = nextBurst.periodUs;
                currentARR = (activePulseWidth > 1) ? (activePulseWidth - 1) : 1;
                uint16_t pWidth = (currentARR > 5) ? 5 : (currentARR / 2);
                if (pWidth < 2) pWidth = 2;
                currentCCR2 = currentARR - pWidth + 1;
                return;
            }

            // Burst complete, no pending items
            hwBurstActive = false;
            hwBurstStepsTarget = 0;
            hwBurstStepsDone = 0;
            movementState = 3; // COMPLETE
        }
    }

    // Emulated sensorISR (PA0 falling edge)
    bool handleTrigger(uint32_t nowUs, uint32_t integerPart = 113, uint32_t fracPart = 176848UL) {
        receivedTriggers++;

        uint32_t diff = 0;
        if (!hasValidPriorTrigger) {
            lastMeasuredIntervalUs = 0;
            currentRPM = 0;
            hasValidPriorTrigger = true;
        } else {
            diff = (uint32_t)(nowUs - lastTriggerMicros);
            if (diff > 2000000UL) {
                // Standstill reset
                lastMeasuredIntervalUs = 0;
                currentRPM = 0;
            } else {
                uint32_t activeBlankingUs = 1500UL;
                if (lastMeasuredIntervalUs > 0) {
                    activeBlankingUs = lastMeasuredIntervalUs / 3UL;
                    if (activeBlankingUs < 1500UL) activeBlankingUs = 1500UL;
                    if (activeBlankingUs > 4500UL) activeBlankingUs = 4500UL;
                }

                // Production rule: never reject a legitimate acceleration edge because
                // it exceeds the configured RPM ceiling. PA0 is the authoritative
                // machine-cycle trigger; only the adaptive EMI blanking window may
                // reject an edge. This protects the 0 -> 3000 RPM startup transition.
                uint32_t triggerQualificationUs = activeBlankingUs;

                if (diff < triggerQualificationUs) {
                    rejectedTriggerCount++;
                    return false; // Sub-blanking glitch/ringing only
                }
                lastMeasuredIntervalUs = diff;
                currentRPM = 60000000UL / diff;
            }
        }

        lastTriggerMicros = nowUs;
        acceptedTriggers++;

        // Calculate exact required steps
        uint32_t steps = dda.step(integerPart, fracPart);
        totalRequestedPulses += steps;

        if (flashTx.isSaveLockActive()) {
            flashTx.deferTrigger(steps, motorDirection, nowUs);
            deferredTriggerCount++;
        } else {
            startHardwareTimerBurst(steps, nowUs, 70);
        }

        return true;
    }

    // Drain all steps until machine is idle
    void runUntilIdle() {
        uint32_t maxTicks = 10000000;
        while ((hwBurstActive || !queue.isEmpty()) && maxTicks-- > 0) {
            if (movementState == 4) break;
            stepTimerTick();
        }
    }
};

int main() {
    std::cout << "========================================================================" << std::endl;
    std::cout << "TEST SUITE: STM32 ZIPPER CNC V16.5.9 — ALL 26 VERIFICATION SCENARIOS" << std::endl;
    std::cout << "========================================================================" << std::endl;

    SimulatedMachineEngine m;

    // -------------------------------------------------------------------------
    // TEST 1: single trigger
    // -------------------------------------------------------------------------
    {
        m.reset();
        bool ok = m.handleTrigger(1000, 113, 0); // Pure integer 113 steps
        assert(ok);
        assert(m.receivedTriggers == 1);
        assert(m.acceptedTriggers == 1);
        assert(m.hwBurstActive);
        assert(m.hwBurstStepsTarget == 113);
        assert(m.currentARR == 69); // 70us period
        assert(m.currentCCR2 == 65); // 5us pulse width (69 - 5 + 1)

        m.runUntilIdle();
        assert(!m.hwBurstActive);
        assert(m.completedStepBursts == 1);
        assert(m.totalCompletedPulses == 113);
        assert(m.totalRequestedPulses == m.totalCompletedPulses);
        std::cout << "[PASS] [01/26] single trigger: Exactly 1 burst, 113 pulses, ARR=69, CCR2=65." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 2: 10 triggers
    // -------------------------------------------------------------------------
    {
        m.reset();
        for (int i = 0; i < 10; i++) {
            uint32_t ts = 10000 + i * 20000; // 20ms spacing (3000 RPM)
            bool ok = m.handleTrigger(ts, 113, 0);
            assert(ok);
            m.runUntilIdle();
        }
        assert(m.receivedTriggers == 10);
        assert(m.acceptedTriggers == 10);
        assert(m.generatedStepBursts == 10);
        assert(m.completedStepBursts == 10);
        assert(m.totalCompletedPulses == 1130);
        assert(m.totalRequestedPulses == m.totalCompletedPulses);
        std::cout << "[PASS] [02/26] 10 triggers: Exactly 10 bursts, 1130 pulses." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 3: 100 triggers
    // -------------------------------------------------------------------------
    {
        m.reset();
        // Size #5: 113.176848 pulses per trigger -> 100 * 113 + 17 carries = 11317 pulses
        for (int i = 0; i < 100; i++) {
            uint32_t ts = 10000 + i * 20000;
            bool ok = m.handleTrigger(ts, 113, 176848UL);
            assert(ok);
            m.runUntilIdle();
        }
        assert(m.receivedTriggers == 100);
        assert(m.acceptedTriggers == 100);
        assert(m.completedStepBursts == 100);
        assert(m.totalCompletedPulses == 11317);
        assert(m.totalRequestedPulses == m.totalCompletedPulses);
        std::cout << "[PASS] [03/26] 100 triggers: 100 bursts, exact DDA pulse conservation (11317 pulses, Error = 0)." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 4: back-to-back triggers
    // -------------------------------------------------------------------------
    {
        m.reset();
        m.handleTrigger(10000, 113, 0);
        for (int p = 0; p < 50; p++) m.stepTimerTick();
        assert(m.hwBurstActive);

        // Trigger 2 arrives while burst 1 is active
        m.handleTrigger(25000, 113, 0);
        assert(m.queue.count() == 1);

        while (m.completedStepBursts == 0) m.stepTimerTick();
        assert(m.hwBurstActive);
        assert(m.completedStepBursts == 1);

        // Trigger 3 arrives
        m.handleTrigger(40000, 113, 0);

        m.runUntilIdle();
        assert(m.completedStepBursts == 3);
        assert(m.totalCompletedPulses == 339);
        std::cout << "[PASS] [04/26] back-to-back triggers: Strict FIFO execution without merging or dropping." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 5: trigger during active burst
    // -------------------------------------------------------------------------
    {
        m.reset();
        m.handleTrigger(1000, 50, 0);
        assert(m.hwBurstActive);
        for (int i = 0; i < 20; i++) m.stepTimerTick();
        assert(m.hwBurstStepsDone == 20);

        // Mid-burst trigger
        bool ok = m.handleTrigger(20000, 60, 0);
        assert(ok);
        assert(m.queue.count() == 1);
        assert(m.queue.queuedSteps() == 60);

        // Active burst completes uninterrupted
        for (int i = 0; i < 30; i++) m.stepTimerTick();
        assert(m.completedStepBursts == 1);
        assert(m.hwBurstActive);
        assert(m.hwBurstStepsTarget == 60);

        m.runUntilIdle();
        assert(m.completedStepBursts == 2);
        assert(m.totalCompletedPulses == 110);
        std::cout << "[PASS] [05/26] trigger during active burst: Enqueued and chained seamlessly at CNT=ARR." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 6: queue pressure
    // -------------------------------------------------------------------------
    {
        m.reset();
        m.handleTrigger(10000, 100, 0);
        assert(m.hwBurstActive);

        for (int i = 1; i <= 20; i++) {
            m.handleTrigger(10000 + i * 16000, 10, 0);
        }
        assert(m.queue.count() == 20);
        assert(m.queue.highWaterMark >= 20);

        m.runUntilIdle();
        assert(m.completedStepBursts == 21);
        assert(m.totalCompletedPulses == 300);
        assert(m.queue.highWaterMark >= 20);
        std::cout << "[PASS] [06/26] queue pressure: 20 bursts backlog tracked with accurate high-water mark." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 7: queue full
    // -------------------------------------------------------------------------
    {
        m.reset();
        m.handleTrigger(10000, 100, 0);
        for (uint32_t i = 1; i <= BURST_QUEUE_CAPACITY; i++) {
            bool ok = m.handleTrigger(10000 + i * 16000, 10, 0);
            assert(ok);
        }
        assert(m.queue.isFull());
        assert(m.queue.count() == BURST_QUEUE_CAPACITY);

        // 33rd trigger: MUST detect overflow explicitly, must not corrupt queue
        bool ok33 = m.handleTrigger(999999, 10, 0);
        assert(ok33);
        assert(m.isTriggerOverflowTripped);
        assert(m.queueOverflowCount == 1);
        assert(m.movementState == 4 /* FAULT */);
        assert(m.queue.isFull());
        assert(m.queue.count() == BURST_QUEUE_CAPACITY);

        BurstItem it{};
        uint32_t drained = 0;
        while (m.queue.dequeue(it)) {
            drained += it.stepCount;
        }
        assert(drained == BURST_QUEUE_CAPACITY * 10);
        std::cout << "[PASS] [07/26] queue full: Overflow explicitly detected, fault latched, queue protected." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 8: queue wrap-around
    // -------------------------------------------------------------------------
    {
        BurstQueue q;
        BurstItem it{};
        // Enqueue and dequeue 10,000 bursts through 32-entry circular buffer
        for (uint32_t c = 0; c < 10000; c++) {
            assert(q.enqueue(50 + (c % 100), (c & 1), c * 100, c + 1));
            assert(q.dequeue(it));
            assert(it.stepCount == 50 + (c % 100));
            assert(it.seq == c + 1);
            assert(q.verifyInvariant());
        }
        assert(q.isEmpty());
        assert(q.droppedPulses == 0);
        assert(q.head == 10000);
        assert(q.tail == 10000);
        std::cout << "[PASS] [08/26] queue wrap-around: 10,000 cycles across circular ring boundary (0 loss)." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 9: timer rollover
    // -------------------------------------------------------------------------
    {
        m.reset();
        uint32_t t_pre_wrap = 0xFFFFFFF0UL; // 16us before wrap
        m.handleTrigger(t_pre_wrap, 100, 0);
        m.runUntilIdle();

        // 20ms later across 32-bit rollover
        uint32_t t_post_wrap = 0x00004E10UL; // Diff = 20000us
        bool ok = m.handleTrigger(t_post_wrap, 100, 0);
        assert(ok);
        assert(m.rejectedTriggerCount == 0);
        assert(m.lastMeasuredIntervalUs == 20000UL);
        m.runUntilIdle();
        assert(m.completedStepBursts == 2);
        assert(m.totalCompletedPulses == 200);
        std::cout << "[PASS] [09/26] timer rollover: 0xFFFFFFFF -> 0 handled seamlessly (diff=20000us, zero loss)." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 10: capture overcapture
    // -------------------------------------------------------------------------
    {
        HardwareCaptureStreamEngine eng;
        assert(eng.diag.captureOverruns == 0);
        assert(!eng.diag.isCaptureStreamDiscontinuous);

        eng.handleHardwareEdge(false, 1000, 10000);
        assert(eng.diag.acceptedPulses == 1);

        eng.handleHardwareEdge(true, 5000, 30000);
        assert(eng.diag.captureOverruns == 1);
        assert(eng.diag.isCaptureStreamDiscontinuous);
        assert(eng.diag.knownLostPulses == 1);
        assert(eng.diag.acceptedPulses == 2);

        eng.handleHardwareEdge(false, 9000, 50000);
        assert(!eng.diag.isCaptureStreamDiscontinuous);
        assert(eng.diag.resyncEvents == 1);
        assert(eng.diag.acceptedPulses == 3);
        std::cout << "[PASS] [10/26] capture overcapture: CC1OF explicitly detected, logged, and resynchronized." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 11: flash-save during trigger activity
    // -------------------------------------------------------------------------
    {
        m.reset();
        // Request lock while active -> rejected
        m.handleTrigger(1000, 50, 0);
        m.flashTx.requestSaveLock();
        bool confirmed = m.flashTx.confirmLockAndTransition(!m.hwBurstActive && m.queue.isEmpty());
        assert(!confirmed);
        m.flashTx.abortLock();
        m.runUntilIdle();

        // Standstill lock -> confirmed
        m.flashTx.requestSaveLock();
        confirmed = m.flashTx.confirmLockAndTransition(true);
        assert(confirmed);
        assert(m.flashTx.lockState == SAVE_LOCK_LOCKED);

        // Triggers arrive during Flash write
        m.handleTrigger(50000, 113, 0);
        m.handleTrigger(70000, 113, 0);
        assert(m.deferredTriggerCount == 2);
        assert(m.flashTx.deferredSteps == 226);

        // Release lock and dispatch
        uint8_t defDir = 0;
        uint32_t defTs = 0;
        uint32_t defSteps = m.flashTx.captureDeferredForDispatch(defDir, defTs);
        assert(defSteps == 226);
        m.flashTx.completeHandoff();

        m.startHardwareTimerBurst(defSteps, defTs, 70);
        m.runUntilIdle();
        assert(m.completedStepBursts == 2);
        assert(m.totalCompletedPulses == 276);
        std::cout << "[PASS] [11/26] flash-save during trigger activity: Triggers deferred & dispatched without loss." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 12: maximum supported trigger rate
    // -------------------------------------------------------------------------
    {
        m.reset();
        m.maxRPMSetting = 4000;
        for (uint32_t i = 0; i < 10; i++) {
            uint32_t ts = 10000 + i * 15000; // 15,000 us (4,000 RPM rated max)
            bool ok = m.handleTrigger(ts, 10, 0);
            assert(ok);
        }
        assert(m.acceptedTriggers == 10);
        assert(m.rejectedTriggerCount == 0);
        m.runUntilIdle();
        assert(m.completedStepBursts == 10);
        std::cout << "[PASS] [12/26] maximum supported trigger rate: 4,000 RPM rated (15ms) accepted without loss." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 13: minimum trigger spacing
    // -------------------------------------------------------------------------
    {
        m.reset();
        m.handleTrigger(10000, 10, 0);
        bool ok1 = m.handleTrigger(10500, 10, 0); // 500us
        assert(!ok1);
        assert(m.rejectedTriggerCount == 1);

        bool ok2 = m.handleTrigger(11200, 10, 0); // 1200us
        assert(!ok2);
        assert(m.rejectedTriggerCount == 2);

        bool ok3 = m.handleTrigger(30000, 10, 0); // 20ms valid
        assert(ok3);
        assert(m.acceptedTriggers == 2);
        m.runUntilIdle();
        assert(m.completedStepBursts == 2);
        std::cout << "[PASS] [13/26] minimum trigger spacing: Edges < 1500us rejected by blanking floor." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 14: invalid/noisy trigger
    // -------------------------------------------------------------------------
    {
        m.reset();
        m.handleTrigger(10000, 50, 0);
        for (int i = 1; i <= 50; i++) {
            bool ok = m.handleTrigger(10000 + i * 20, 50, 0);
            assert(!ok);
        }
        assert(m.rejectedTriggerCount == 50);
        assert(m.acceptedTriggers == 1);
        m.runUntilIdle();
        assert(m.completedStepBursts == 1);
        assert(m.totalCompletedPulses == 50);
        std::cout << "[PASS] [14/26] invalid/noisy trigger: 50 contactor EMI noise spikes filtered." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 15: start/stop
    // -------------------------------------------------------------------------
    {
        m.reset();
        assert(m.movementState == 0);
        m.handleTrigger(1000, 100, 0);
        assert(m.movementState == 1);
        m.runUntilIdle();
        assert(m.movementState == 3);

        uint32_t nowUs = 1000 + 2500000UL;
        if (nowUs - m.lastTriggerMicros > 2000000UL) {
            m.movementState = 0;
            m.currentRPM = 0;
            m.hasValidPriorTrigger = false;
        }
        assert(m.movementState == 0);
        m.handleTrigger(nowUs, 100, 0);
        assert(m.movementState == 1);
        m.runUntilIdle();
        assert(m.completedStepBursts == 2);
        assert(m.totalCompletedPulses == 200);

        // Rapid servo acceleration regression: 0 -> 1000 RPM -> 3000 RPM.
        // The old max-RPM plausibility floor rejected the 20 ms edge after a
        // 60 ms interval (it required >= 40 ms). That would lose one needle cycle.
        // Production behavior must accept the authoritative PA0 edge and adapt.
        m.reset();
        assert(m.handleTrigger(0, 100, 0));       // first edge / startup
        assert(m.handleTrigger(60000, 100, 0));  // ~1000 RPM
        assert(m.handleTrigger(80000, 100, 0));  // ~3000 RPM: MUST NOT be rejected
        assert(m.rejectedTriggerCount == 0);
        assert(m.acceptedTriggers == 3);
        assert(m.lastMeasuredIntervalUs == 20000UL);
        m.runUntilIdle();
        assert(m.completedStepBursts == 3);
        assert(m.totalCompletedPulses == 300);

        std::cout << "[PASS] [15/26] start/stop + rapid 0->1000->3000 RPM acceleration: zero rejected real triggers." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 16: exact STEP count
    // -------------------------------------------------------------------------
    {
        struct SizeTest {
            int sizeNum;
            uint32_t intPart;
            uint32_t fracPart;
        } sizes[3] = {
            {5, 113, 176848UL},
            {8, 135, 812218UL},
            {10, 181, 82957UL}
        };

        for (auto &sz : sizes) {
            m.reset();
            for (int i = 0; i < 50; i++) {
                m.handleTrigger(1000 + i * 20000, sz.intPart, sz.fracPart);
                m.runUntilIdle();
            }
            assert(m.totalRequestedPulses == m.totalCompletedPulses);
            assert(m.completedStepBursts == 50);
            assert(m.queue.verifyInvariant());
        }
        std::cout << "[PASS] [16/26] exact STEP count: Conserved exactly for Size #5, #8, and #10." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 17: trigger-to-burst conservation
    // -------------------------------------------------------------------------
    {
        m.reset();
        for (int i = 0; i < 42; i++) {
            m.handleTrigger(1000 + i * 20000, 75, 0);
            m.runUntilIdle();
        }
        assert(m.acceptedTriggers == 42);
        assert(m.completedStepBursts == 42);
        assert(m.acceptedTriggers == m.completedStepBursts);
        std::cout << "[PASS] [17/26] trigger-to-burst conservation: acceptedTriggers (42) == completedStepBursts (42)." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 18: duplicate-burst detection
    // -------------------------------------------------------------------------
    {
        BurstQueue testQ;
        for (uint32_t i = 1; i <= 30; i++) {
            testQ.enqueue(10, 0, i * 100, i);
        }
        BurstItem it{};
        uint32_t lastSeq = 0;
        uint32_t count = 0;
        while (testQ.dequeue(it)) {
            assert(it.seq == lastSeq + 1);
            lastSeq = it.seq;
            count++;
        }
        assert(count == 30);
        assert(lastSeq == 30);
        std::cout << "[PASS] [18/26] duplicate-burst detection: Monotonic sequence verified, 0 duplicate bursts." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 19: missing-burst detection
    // -------------------------------------------------------------------------
    {
        m.reset();
        for (int i = 0; i < 30; i++) {
            m.handleTrigger(1000 + i * 20000, 50, 0);
        }
        m.runUntilIdle();
        assert(m.queue.isEmpty());
        assert(m.completedStepBursts == 30);
        assert(m.totalCompletedPulses == 30 * 50);
        std::cout << "[PASS] [19/26] missing-burst detection: Every accepted trigger accounts for exactly 1 burst." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 20: PA0 configuration
    // -------------------------------------------------------------------------
    {
        std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
        assert(f.is_open());
        std::stringstream ss;
        ss << f.rdbuf();
        std::string fw = ss.str();

        assert(fw.find("pinMode(proxSensorPin, INPUT_PULLUP);") != std::string::npos);
        assert(fw.find("attachInterrupt(digitalPinToInterrupt(proxSensorPin), sensorISR, FALLING);") != std::string::npos);
        assert(fw.find("NVIC_SetPriority(EXTI0_IRQn, 1);") != std::string::npos);
        std::cout << "[PASS] [20/26] PA0 configuration: INPUT_PULLUP, EXTI0 FALLING, Priority 1 verified." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 21: PA1 configuration
    // -------------------------------------------------------------------------
    {
        std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
        assert(f.is_open());
        std::stringstream ss;
        ss << f.rdbuf();
        std::string fw = ss.str();

        assert(fw.find("const int stepPin           = PA1;") != std::string::npos);
        assert(fw.find("GPIOA->CRL |= (0xBU << 4);") != std::string::npos); // AF Push-Pull 50MHz
        assert(fw.find("STEP_PULSE_WIDTH_US   = 5") != std::string::npos); // 5.0us active-LOW
        assert(fw.find("STEP_HIGH_IDLE()") != std::string::npos);
        std::cout << "[PASS] [21/26] PA1 configuration: AF Push-Pull 50MHz, 5.0us pulse, idle HIGH verified." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 22: TIM2 CH1 configuration
    // -------------------------------------------------------------------------
    {
        std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
        assert(f.is_open());
        std::stringstream ss;
        ss << f.rdbuf();
        std::string fw = ss.str();

        assert(fw.find("TIM2->CCMR1 |= TIM_CCMR1_CC1S_0;") != std::string::npos); // CC1 mapped on TI1
        assert(fw.find("TIM2->CCMR1 |= (0xFU << 4);") != std::string::npos);     // IC1F=1111 filter
        assert(fw.find("TIM2->CCER  |= (TIM_CCER_CC1P | TIM_CCER_CC1E);") != std::string::npos);
        assert(fw.find("TIM2->SR & TIM_SR_CC1OF") != std::string::npos);         // Overcapture check
        std::cout << "[PASS] [22/26] TIM2 CH1 configuration: TI1 Input Capture, IC1F=1111 filter, CC1OF handling." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 23: TIM2 CH2 configuration
    // -------------------------------------------------------------------------
    {
        std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
        assert(f.is_open());
        std::stringstream ss;
        ss << f.rdbuf();
        std::string fw = ss.str();

        assert(fw.find("TIM2->PSC = 71;") != std::string::npos);                  // 1MHz timebase
        assert(fw.find("TIM2->CCMR1 |= (0x7U << 12);") != std::string::npos);    // PWM Mode 2
        assert(fw.find("TIM2->CCMR1 |= TIM_CCMR1_OC2PE;") != std::string::npos); // Preload Enable
        assert(fw.find("TIM2->CCER |= TIM_CCER_CC2P;") != std::string::npos);    // Active-LOW polarity
        assert(fw.find("TIM2->CR1 |= TIM_CR1_ARPE;") != std::string::npos);      // ARPE shadow buffer
        assert(fw.find("NVIC_SetPriority(TIM2_IRQn, 0);") != std::string::npos); // Highest priority 0
        std::cout << "[PASS] [23/26] TIM2 CH2 configuration: 1MHz, PWM Mode 2, ARPE, OC2PE, Priority 0 verified." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 24: ISR/queue concurrency
    // -------------------------------------------------------------------------
    {
        BurstQueue sharedQ;
        std::atomic<bool> producerDone{false};
        std::atomic<uint32_t> totalProducedPulses{0};
        std::atomic<uint32_t> totalConsumedPulses{0};

        const uint32_t ITEM_COUNT = 50000;

        // Producer thread (simulating sensorISR)
        std::thread producer([&]() {
            for (uint32_t i = 1; i <= ITEM_COUNT; i++) {
                uint32_t steps = 10 + (i % 20);
                while (sharedQ.isFull()) {
                    std::this_thread::yield();
                }
                bool ok = sharedQ.enqueue(steps, 0, i * 10, i);
                assert(ok);
                totalProducedPulses += steps;
            }
            producerDone = true;
        });

        // Consumer thread (simulating stepTimerCallback)
        std::thread consumer([&]() {
            BurstItem item{};
            while (!producerDone || !sharedQ.isEmpty()) {
                if (sharedQ.dequeue(item)) {
                    totalConsumedPulses += item.stepCount;
                } else {
                    std::this_thread::yield();
                }
            }
        });

        producer.join();
        consumer.join();

        assert(sharedQ.isEmpty());
        assert(totalProducedPulses == totalConsumedPulses);
        assert(sharedQ.verifyInvariant());
        assert(sharedQ.droppedPulses == 0);
        std::cout << "[PASS] [24/26] ISR/queue concurrency: 50,000 multi-threaded SPSC transitions verified lock-free." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 25: long continuous operation (100,000 cycles)
    // -------------------------------------------------------------------------
    {
        BurstQueue q;
        BurstItem it{};
        DdaAccumulator acc;
        const uint32_t CYCLES = 100000;
        uint32_t req = 0;
        uint32_t comp = 0;

        for (uint32_t i = 0; i < CYCLES; i++) {
            uint32_t st = acc.step(113, 176848UL);
            req += st;
            assert(q.enqueue(st, 0, i * 20, i + 1));
            assert(q.dequeue(it));
            comp += it.stepCount;
        }
        assert(req == comp);
        assert(req == 11317684); // Exactly 113.176848 * 100000
        assert(q.verifyInvariant());
        std::cout << "[PASS] [25/26] long continuous operation: 100,000 cycles (11,317,684 pulses) verified (Error = 0.000000)." << std::endl;
    }

    // -------------------------------------------------------------------------
    // TEST 26: fault recovery
    // -------------------------------------------------------------------------
    {
        m.reset();
        // Trip queue overflow fault
        m.handleTrigger(1000, 100, 0);
        for (uint32_t i = 1; i <= BURST_QUEUE_CAPACITY; i++) {
            m.handleTrigger(1000 + i * 16000, 10, 0);
        }
        m.handleTrigger(999999, 10, 0); // 33rd -> triggers fault
        assert(m.movementState == 4 /* FAULT */);
        assert(m.isTriggerOverflowTripped);
        assert(m.motionRelayActive); // Relay tripped

        // While running / RPM > 0, fault CANNOT clear
        m.currentRPM = 1500;
        if (m.currentRPM == 0) {
            m.movementState = 0;
        }
        assert(m.movementState == 4);
        assert(m.motionRelayActive);

        // Once at complete standstill (0 RPM) and queue drained:
        m.currentRPM = 0;
        m.queue.reset();
        m.hwBurstActive = false;
        if (m.currentRPM == 0 && m.queue.isEmpty() && !m.hwBurstActive) {
            m.isTriggerOverflowTripped = false;
            m.motionRelayActive = false; // Relay released
            m.movementState = 0; // Recovered to IDLE
        }
        assert(m.movementState == 0);
        assert(!m.isTriggerOverflowTripped);
        assert(!m.motionRelayActive);

        // Resume clean operation
        bool ok = m.handleTrigger(2000000, 113, 0);
        assert(ok);
        assert(m.movementState == 1);
        m.runUntilIdle();
        assert(m.movementState == 3);
        std::cout << "[PASS] [26/26] fault recovery: Gated strictly to 0 RPM standstill; safe recovery verified." << std::endl;
    }

    std::cout << "========================================================================" << std::endl;
    std::cout << "ALL 26 VERIFICATION SCENARIOS PASSED WITH 100% SUCCESS RATE!" << std::endl;
    std::cout << "========================================================================" << std::endl;
    return 0;
}
