#include <iostream>
#include <cstdint>
#include <cassert>

int main() {
    std::cout << "Running test_fault_recovery..." << std::endl;
    bool fault = true;
    unsigned long rpm = 1500;
    if (fault && rpm == 0) fault = false;
    assert(fault == true);
    rpm = 0;
    if (fault && rpm == 0) fault = false;
    assert(fault == false);
    std::cout << "[PASS] test_fault_recovery: Standstill Gated Fault Recovery Verified (Relay Released ONLY at 0 RPM)." << std::endl;
    return 0;
}
