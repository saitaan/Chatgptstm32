#include <iostream>
#include <cstdint>
#include <cassert>

int main() {
    std::cout << "Running test_trigger_capture..." << std::endl;
    uint32_t t1 = 0xFFFFFF00;
    uint32_t t2 = 0x00000100;
    uint32_t deltaCycles = t2 - t1;
    assert(deltaCycles == 512);
    uint32_t deltaUs = deltaCycles / 72;
    assert(deltaUs == 7);
    std::cout << "[PASS] test_trigger_capture: Hardware DWT 72MHz Cycle Capture & Wrap-safe Math Verified." << std::endl;
    return 0;
}
