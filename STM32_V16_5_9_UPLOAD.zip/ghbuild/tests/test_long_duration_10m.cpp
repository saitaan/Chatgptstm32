#include <iostream>
#include <cassert>
#include <cstdint>
#include "../include/burst_queue.h"
#include "../include/motion_scheduler.h"

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Long-Duration Workload (10,000,000 Pulses / 1,000,000 Triggers)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    const uint32_t TARGET_TRIGGERS = 1000000;
    const uint32_t TARGET_PULSES   = 10000000;

    BurstQueue queue;
    DdaAccumulator dda;

    // Fixed-scale: 10 pulses per trigger + 0.123456 fractional
    const uint32_t intPart  = 10;
    const uint32_t fracPart = 123456;

    uint32_t generatedTriggers = 0;
    uint32_t simulatedTimestampUs = 0;
    uint16_t simulatedTimer16Bit = 0;

    while (queue.consumedPulses < TARGET_PULSES || generatedTriggers < TARGET_TRIGGERS) {
        // Produce triggers
        if (generatedTriggers < TARGET_TRIGGERS && !queue.isFull()) {
            uint32_t steps = dda.step(intPart, fracPart);
            uint8_t  dir   = ((generatedTriggers / 1000) & 1); // Alternate directions every 1000 bursts
            
            // Advance simulated continuous timestamps (exercising 32-bit and 16-bit rollovers)
            simulatedTimestampUs += 40000; // 40ms interval (~1500 RPM)
            simulatedTimer16Bit   = (uint16_t)(simulatedTimer16Bit + 40000);

            bool ok = queue.enqueue(steps, dir, simulatedTimestampUs, generatedTriggers + 1);
            assert(ok);
            generatedTriggers++;
        }

        // Consume bursts
        BurstItem item{};
        if (queue.dequeue(item)) {
            // Validate step by step execution
            for (uint32_t s = 0; s < item.stepCount; s++) {
                uint16_t arr = MotionScheduler::calculateStepPeriodARR(s, item.stepCount, 70);
                assert(arr >= 69 && arr <= 120);
            }
        }

        if ((generatedTriggers % 100000) == 0 && generatedTriggers > 0 && queue.isEmpty()) {
            assert(queue.verifyInvariant());
            assert(queue.droppedPulses == 0);
            std::cout << " -> Progress: " << generatedTriggers << " triggers, "
                      << queue.consumedPulses << " pulses processed..." << std::endl;
        }
    }

    // Drain any remaining
    BurstItem rem{};
    while (queue.dequeue(rem)) {}

    assert(queue.isEmpty());
    assert(queue.droppedPulses == 0);
    assert(queue.submittedPulses == queue.consumedPulses);
    assert(queue.verifyInvariant());

    std::cout << "[PASS] Workload Complete: " << queue.consumedPulses << " Pulses Processed." << std::endl;
    std::cout << "[PASS] Total Triggers   : " << generatedTriggers << std::endl;
    std::cout << "[PASS] Dropped Pulses   : " << queue.droppedPulses << std::endl;
    std::cout << "[PASS] Invariant Status : EXACT MATCH (Zero Drift, Zero Loss)" << std::endl;

    std::cout << "==========================================================" << std::endl;
    std::cout << "LONG-DURATION TEST PASSED (100% GREEN)" << std::endl;
    std::cout << "==========================================================" << std::endl;
    return 0;
}
