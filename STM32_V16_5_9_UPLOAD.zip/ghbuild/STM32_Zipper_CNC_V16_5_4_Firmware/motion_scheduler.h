#ifndef MOTION_SCHEDULER_H
#define MOTION_SCHEDULER_H

#include <stdint.h>
#include <stdbool.h>
#include <algorithm>

// =========================================================================
// DETERMINISTIC MOTION SCHEDULER & MICRO-FRACTIONAL DDA ENGINE
// 1. Fixed Scale: 1,000,000x (6 decimal places of precision, zero float).
// 2. Bounded Profile: Maximum adjacent step period delta <= 7.0 us (<= 10%).
// 3. Short-Burst Specialization: Explicitly tuned for 1..256+ pulse bursts.
// 4. Direction Safety: 20 us setup and hold delay strictly enforced.
// =========================================================================

#define FIXED_SCALE_FACTOR 1000000ULL
#define DIR_SAFETY_DELAY_US 20U // 400% margin over Leadshine DM542 5.0us spec

class DdaAccumulator {
public:
    uint32_t accumulator;
    uint32_t totalIntegerSteps;
    uint32_t totalCarrySteps;

    DdaAccumulator() : accumulator(0), totalIntegerSteps(0), totalCarrySteps(0) {}

    void reset() {
        accumulator = 0;
        totalIntegerSteps = 0;
        totalCarrySteps = 0;
    }

    // Accumulates fractional microsteps and returns generated steps for this trigger
    inline uint32_t step(uint32_t integerPart, uint32_t fractionalPart) {
        uint32_t steps = integerPart;
        totalIntegerSteps += integerPart;

        accumulator += fractionalPart;
        if (accumulator >= FIXED_SCALE_FACTOR) {
            steps++;
            totalCarrySteps++;
            accumulator -= FIXED_SCALE_FACTOR;
        }
        return steps;
    }

    inline uint32_t totalPulses() const {
        return totalIntegerSteps + totalCarrySteps;
    }
};

class MotionScheduler {
public:
    // Multi-segment ramp parameter calculator
    // targetSteps: Total pulses in the burst
    // rampSteps  : Number of acceleration / deceleration steps
    // f_bound    : Initial / final period multiplier (1000 = 1.000x)
    static inline void calculateRamp(uint32_t targetSteps, uint32_t &rampSteps, uint32_t &f_bound) {
        const uint32_t MAX_RAMP = 12U;
        if (targetSteps <= 4U) {
            rampSteps = 0U;
            f_bound   = 1000U;
        } else if (targetSteps < 8U) {
            rampSteps = 1U;
            f_bound   = 1060U; // 1.06x -> 74us starting period (+4us delta, 5.7%)
        } else if (targetSteps <= 12U) {
            rampSteps = 2U;
            f_bound   = 1120U; // 1.12x -> 78us starting period (+4us delta, 5.4%)
        } else {
            rampSteps = targetSteps / 3U;
            if (rampSteps > MAX_RAMP) rampSteps = MAX_RAMP;
            f_bound   = 1000U + ((600U * rampSteps) / MAX_RAMP);
        }
    }

    // Calculates the timer Auto-Reload Register (ARR) value for step index 'stepIndex'
    // in a burst of 'targetSteps', with nominal active pulse width 'nominalPulseWidthUs'
    static inline uint16_t calculateStepPeriodARR(uint32_t stepIndex, uint32_t targetSteps, uint16_t nominalPulseWidthUs) {
        if (targetSteps == 0) return 0;

        uint32_t rampSteps;
        uint32_t f_bound;
        calculateRamp(targetSteps, rampSteps, f_bound);

        uint16_t nominalARR = (nominalPulseWidthUs > 1) ? (uint16_t)(nominalPulseWidthUs - 1) : 1;
        if (rampSteps == 0) {
            return nominalARR;
        }

        uint32_t remaining = (targetSteps > stepIndex) ? (targetSteps - stepIndex) : 0;
        uint16_t targetARR = nominalARR;

        if (stepIndex < rampSteps) {
            // Acceleration phase
            uint32_t f_cur = f_bound - (((f_bound - 1000U) * stepIndex) / rampSteps);
            uint32_t period = ((uint32_t)nominalPulseWidthUs * f_cur) / 1000U;
            targetARR = (period > 1) ? (uint16_t)(period - 1) : 1;
        } else if (remaining <= rampSteps) {
            // Deceleration phase (Symmetric mirror of acceleration)
            uint32_t decelIndex = rampSteps - remaining;
            uint32_t f_cur = 1000U + (((f_bound - 1000U) * (decelIndex + 1U)) / rampSteps);
            uint32_t period = ((uint32_t)nominalPulseWidthUs * f_cur) / 1000U;
            targetARR = (period > 1) ? (uint16_t)(period - 1) : 1;
        }

        return targetARR;
    }

    // Bidirectional Slew Limiter for safe period transitions
    static inline uint16_t applySlewLimiter(uint16_t targetARR, uint16_t currentARR, uint16_t nominalPulseWidthUs) {
        if (currentARR == 0) return targetARR;
        uint16_t maxDelta = (uint16_t)(((uint32_t)nominalPulseWidthUs * 100U) / 1000U); // 10% maximum
        if (maxDelta < 1) maxDelta = 1;

        if (targetARR < currentARR && (currentARR - targetARR) > maxDelta) {
            return currentARR - maxDelta;
        } else if (targetARR > currentARR && (targetARR - currentARR) > maxDelta) {
            return currentARR + maxDelta;
        }
        return targetARR;
    }
};

#endif // MOTION_SCHEDULER_H
