# V16.5.8 Verification Report

Baseline: V16.5.7 SIMULATED HARDENED.

## Implemented fixes
- Added STM32F1 TIM2 CH1 input-capture digital filter configuration (`IC1F=1111`) as capture-side glitch qualification.
- Kept EXTI0 as the low-latency primary trigger path; therefore the TIM2 IC filter does **not** by itself filter the EXTI signal. Existing software plausibility/blanking remains authoritative for PA0 trigger acceptance.
- Added explicit manual Pulse Tune feasibility checking. An impossible pulse count is no longer silently converted to the 8 us timer floor.
- Primary trigger dispatch is blocked while `pulseTimingInvalid` is active.
- Pulse Tune UP is rejected before applying a setting that would violate the 8 us minimum period.

## Host verification
- Existing C++ test suite: **25/25 passed**.
- Dedicated V16.5.8 hardening regression: **PASS**.
- Firmware braces: **247/247**.
- Firmware parentheses: **1361/1361**.

## Important hardware qualification note
The TIM2 IC filter is capture-side qualification only because PA0 EXTI remains the low-latency trigger source. A factory oscilloscope/logic-analyzer test is still required to validate real EMI rejection and confirm PA0/PA1 timing on the actual STM32F103C8T6 machine.
