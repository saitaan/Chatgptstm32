# GitHub Android Build

This repository is prepared for GitHub Actions compilation of the STM32F103C8T6 firmware.

## Android browser
1. Upload all repository files to GitHub.
2. Open **Actions**.
3. Select **Build STM32 Firmware**.
4. Tap **Run workflow**.
5. When complete, open the workflow run and download artifact **STM32-V16.5.9-firmware**.

The workflow builds for the Blue Pill / STM32F103C8T6 target using Arduino CLI and produces the firmware `.bin` (and other build outputs when available).
